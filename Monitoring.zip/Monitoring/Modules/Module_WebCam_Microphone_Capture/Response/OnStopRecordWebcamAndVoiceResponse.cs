﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module_WebCam_Microphone_Capture.Response
{
    public class OnStopRecordWebcamAndVoiceResponse:OnStartRecordWebcamAndVoiceResponse
    {
    }
}
