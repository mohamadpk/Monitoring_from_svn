﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module_Internet_Reporter.Communication_Manager.Site_Manager.Response
{
    public class OnEnableSiteResponse: OnDisableSiteResponse
    {
    }
}
