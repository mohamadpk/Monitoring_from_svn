﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module_Internet_Reporter.Communication_Manager.WiFi_Logger.Response
{
    public class OnStopWifiWatcherResponse : OnStartWifiWatcherResponse
    {
    }
}
