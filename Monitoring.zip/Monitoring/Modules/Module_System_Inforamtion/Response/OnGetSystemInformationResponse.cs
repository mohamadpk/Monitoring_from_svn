﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module_System_Inforamtion.Response
{
    public class OnGetSystemInformationResponse
    {
        public string Output;
        public Utils._s_Utils_ErrosHandling Errors = new Utils._s_Utils_ErrosHandling();
    }
}
