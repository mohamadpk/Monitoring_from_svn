﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module_USB_Watching.Response
{
    public class OnRemoveUSBFromBlackListResponse: OnStartUSBWatcherResponse
    {
    }
}
