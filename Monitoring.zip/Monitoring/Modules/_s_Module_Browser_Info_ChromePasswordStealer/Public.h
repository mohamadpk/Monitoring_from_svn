#pragma once

struct INFO {
	char url[4096];
	char uname[1024];
	char upass[1024];
	bool it;
};
INFO *info;