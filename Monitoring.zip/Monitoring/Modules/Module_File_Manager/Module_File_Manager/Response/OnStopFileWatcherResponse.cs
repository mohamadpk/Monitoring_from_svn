﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module_File_Manager.Response
{
    public class OnStopFileWatcherResponse : OnStartCreateDrivesTreeResponse
    {
    }
}
