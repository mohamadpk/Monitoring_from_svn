﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module_Process_Manager;

namespace Module_Software_Manager
{
    class Program
    {
        static void Main(string[] args)
        {
            ////_m_Process_Manager mpm = new _m_Process_Manager();
            ////mpm.OnGetProcessList();
            //////_m_Software_Manager msm = new _m_Software_Manager();
            //////msm.OnUninstallSoftware(@"C:\Program Files\FileZilla FTP Client\uninstall.exe");
            //////msm.OnStartBlackSoftwareUnInstaller();
        }
    }
}
